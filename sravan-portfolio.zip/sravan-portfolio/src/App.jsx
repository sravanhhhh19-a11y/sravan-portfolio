import { useState } from 'react';

const projects = [
  { number: '01', type: 'VIDEOGRAPHY', title: 'Visual stories', description: 'Cinematic moments, thoughtful framing and movement that bring a story to life.', tag: 'Video production' },
  { number: '02', type: 'VIDEO EDITING', title: 'The final cut', description: 'A polished edit built around rhythm, pacing, colour and sound.', tag: 'Post-production' },
  { number: '03', type: 'WEB DEVELOPMENT', title: 'Digital experiences', description: 'Clean, responsive web experiences with a focus on clarity and usability.', tag: 'Web design & build' },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="#home" onClick={closeMenu}>SS<span>.</span></a>
        <button className="menu-toggle" aria-label="Toggle navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          <span></span><span></span>
        </button>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#skills" onClick={closeMenu}>Skills</a>
          <a href="#work" onClick={closeMenu}>Work</a>
          <a href="#contact" className="nav-contact" onClick={closeMenu}>Let's talk <span>↗</span></a>
        </nav>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="eyebrow"><span className="status-dot"></span> AVAILABLE FOR CREATIVE PROJECTS</div>
          <div className="hero-grid">
            <div>
              <p className="hero-kicker">HELLO, I'M</p>
              <h1>Sravan<br /><span>Satheesh.</span></h1>
            </div>
            <div className="hero-copy">
              <p className="hero-role">Videographer <i>•</i> Video Editor</p>
              <p className="hero-description">I create visual stories and digital experiences with a focus on detail, emotion and simplicity.</p>
              <a className="text-link" href="#work">Explore my work <span>↘</span></a>
            </div>
          </div>
          <div className="hero-bottom">
            <span>CREATIVE PORTFOLIO / 2026</span>
            <span>BASED IN INDIA</span>
            <a href="#about">SCROLL TO EXPLORE ↓</a>
          </div>
        </section>

        <section className="intro section-wrap" id="about">
          <div className="section-label"><span>01</span> / ABOUT</div>
          <div className="intro-content">
            <h2>Making ideas<br /> <span>look and feel</span> real.</h2>
            <div className="intro-text">
              <p className="large-copy">I'm Sravan — a videographer and video editor with an interest in building for the web.</p>
              <p>I enjoy shaping raw ideas into clear, engaging visual experiences. From capturing a moment to refining the final frame, I care about the small details that make creative work memorable.</p>
              <p>This portfolio is a snapshot of my creative direction, skills and work. More projects will be added as I go.</p>
            </div>
          </div>
        </section>

        <section className="skills section-wrap" id="skills">
          <div className="section-label"><span>02</span> / WHAT I DO</div>
          <div className="skills-grid">
            <div><span className="skill-index">01</span><h3>Videography</h3><p>Capturing people, places and stories through intentional visuals.</p></div>
            <div><span className="skill-index">02</span><h3>Video editing</h3><p>Turning footage into a focused story through pacing, sound and colour.</p></div>
            <div><span className="skill-index">03</span><h3>Web development</h3><p>Creating clean, responsive websites that are easy to explore.</p></div>
          </div>
        </section>

        <section className="work section-wrap" id="work">
          <div className="work-heading">
            <div className="section-label"><span>03</span> / SELECTED WORK</div>
            <p>A few creative directions I'm exploring.</p>
          </div>
          <div className="project-list">
            {projects.map((project) => (
              <article className="project" key={project.number}>
                <div className="project-visual">
                  <span className="visual-number">{project.number}</span>
                  <span className="visual-mark">✳</span>
                  <span className="visual-caption">{project.type}</span>
                </div>
                <div className="project-info">
                  <div><span className="project-tag">{project.tag}</span><h3>{project.title}</h3><p>{project.description}</p></div>
                  <span className="project-arrow">↗</span>
                </div>
              </article>
            ))}
          </div>
          <p className="work-note">These are editable starter project cards. Replace them with screenshots, video thumbnails and links to your real work.</p>
        </section>

        <section className="contact section-wrap" id="contact">
          <div className="section-label"><span>04</span> / CONTACT</div>
          <div className="contact-content">
            <p className="contact-kicker">HAVE A PROJECT IN MIND?</p>
            <h2>Let's make<br /><span>something great.</span></h2>
            <a className="contact-button" href="mailto:hello@example.com">Get in touch <span>↗</span></a>
          </div>
          <div className="contact-foot">
            <span>SRAVAN SATHEESH © 2026</span>
            <div><a href="https://www.instagram.com/" target="_blank" rel="noreferrer">INSTAGRAM ↗</a><a href="https://www.linkedin.com/" target="_blank" rel="noreferrer">LINKEDIN ↗</a></div>
            <a href="#home">BACK TO TOP ↑</a>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
