# Sravan Satheesh — Portfolio

A minimal, responsive React portfolio built with Vite.

## Requirements
- Ubuntu
- Node.js 20+ (Node.js 22 recommended)
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL shown in the terminal (normally http://localhost:5173).

## Create a production build
```bash
npm run build
npm run preview
```

## Personalise before publishing
1. In `src/App.jsx`, update the intro, project cards and contact details.
2. Replace `hello@example.com` with your real email address.
3. Replace the Instagram and LinkedIn profile URLs with your own.
4. Add your real work samples by replacing the placeholder project panels with image/video thumbnails and links.

## Publish
After `npm run build`, the production website is generated in the `dist/` folder. You can deploy that folder to a static hosting service such as Netlify, Vercel or GitHub Pages.
